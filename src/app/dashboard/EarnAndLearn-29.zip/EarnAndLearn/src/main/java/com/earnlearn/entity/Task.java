package com.earnlearn.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Task")
public class Task {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int tid;
	private String name;
	private String startDate;
	private String endDate;
	private String comment;
	private String description;
	private int quantity;
	private String status;
	private Date modifiedOn;
	private Date createdOn;
	
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinColumn(foreignKey = @ForeignKey(name="uid"), name="uid")
	private List<User>  user;
	

	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getQuantity() {
		return quantity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public List<User> getUser() {
		return user;
	}

	public void setUser(List<User> user) {
		this.user = user;
	}

	public Task(int tid, String name, String startDate, String endDate, String comment, String description,
			int quantity, String status, Date modifiedOn, Date createdOn, List<User> user) {
		super();
		this.tid = tid;
		this.name = name;
		this.startDate = startDate;
		this.endDate = endDate;
		this.comment = comment;
		this.description = description;
		this.quantity = quantity;
		this.status = status;
		this.modifiedOn = modifiedOn;
		this.createdOn = createdOn;
		this.user = user;
	}

	public Task() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Task [tid=" + tid + ", name=" + name + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", comment=" + comment + ", description=" + description + ", quantity=" + quantity + ", status="
				+ status + ", modifiedOn=" + modifiedOn + ", createdOn=" + createdOn + ", user=" + user + "]";
	}

	

}
