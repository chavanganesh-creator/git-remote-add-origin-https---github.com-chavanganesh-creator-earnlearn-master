package com.earnlearn.exception;

/**
 * Runtime exception for checking entered age is valid or not at the time of account creation 
 * 
 * @author rutuja jadav
 * @date 9/10/2021
 * 
 */

public class InvalidAgeException extends RuntimeException{
	public InvalidAgeException() {
		
	}
	public InvalidAgeException(String msg) {
		super(msg);
	}
}
