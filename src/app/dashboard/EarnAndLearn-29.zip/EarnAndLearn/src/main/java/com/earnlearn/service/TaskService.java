package com.earnlearn.service;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.earnlearn.dao.TaskDaoInterface;
import com.earnlearn.entity.Task;
import com.earnlearn.serviceImpl.TaskServiceInterface;

@Service
public class TaskService implements TaskServiceInterface {

	@Autowired
	TaskDaoInterface taskDaoInterface;

	@Override
	public Task saveTask(Task task) {
		// TODO Auto-generated method stub
		task.setCreatedOn(new Date());
		task.setModifiedOn(new Date());
	
		return 	taskDaoInterface.save(task); 
	}

	@Override
	public Task updateTask(Task task) {
		// TODO Auto-generated method stub
		task.setModifiedOn(new Date());
		return taskDaoInterface.saveAndFlush(task);
	}

	@Override
	public void deleteTaskById(int id) {
		// TODO Auto-generated method stub
		taskDaoInterface.deleteById(id);
	}

	@Override
	public Task getById(int id) {
		// TODO Auto-generated method stub
		return taskDaoInterface.findById(id).get();
	}

	@Override
	public List<Task> getTaskList() {
		// TODO Auto-generated method stub
		return taskDaoInterface.findAll();
	}

}
